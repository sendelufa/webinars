package ex1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Divisor {
     private final int[] dividers;
     private final int startRange;
     private final int finishRange;

    public Divisor(int[] dividers, int startRange, int finishRange) {
        this.dividers = dividers;
        this.startRange = startRange;
        this.finishRange = finishRange;
    }

    List<Integer> findDividers(){
        List<Integer> dividers = new ArrayList<>();
        for(int i = 0; i < finishRange; i++){
            if (isDivide(i)) {
                dividers.add(startRange);
            }
        }
        return dividers;
    }

    private boolean isDivide(int number){
        for (int i = 0; i < dividers.length; i++){
            if (number %  i == 0){
                return true;
            }
        }
        return false;
    }

    public String formattedDividers(){
        return findDividers()
                .stream()
                .map(String::valueOf)
                .map(s -> "[" + s + "]")
                .collect(Collectors.joining(", "));
    }
}
