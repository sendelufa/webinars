package ex1;


import java.util.List;

public class Main {
    public static void main(String[] args) {

        int[] dividers = new int[]{2, 50};
        int startRange = 0;
        int finishRange = 100_000;

        Divisor divisor = new Divisor(dividers, startRange, finishRange);
        List<Integer> divisors = divisor.findDividers();

        System.out.println(divisors);
        System.out.println(divisor.formattedDividers());
    }


}
